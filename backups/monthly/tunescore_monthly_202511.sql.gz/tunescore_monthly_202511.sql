--
-- PostgreSQL database dump
--

\restrict IOQmb81ggiNu7qFEEI84a99TBJcLcfP88PhYjNZ1cchXRHA9jeOgdBO8SBhVUmh

-- Dumped from database version 18.0 (Ubuntu 18.0-1.pgdg24.04+3)
-- Dumped by pg_dump version 18.0 (Ubuntu 18.0-1.pgdg24.04+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: dwood
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO dwood;

--
-- Name: analyses; Type: TABLE; Schema: public; Owner: dwood
--

CREATE TABLE public.analyses (
    id integer NOT NULL,
    track_id integer NOT NULL,
    sonic_genome jsonb DEFAULT '{}'::jsonb,
    lyrical_genome jsonb DEFAULT '{}'::jsonb,
    hook_data jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.analyses OWNER TO dwood;

--
-- Name: analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: dwood
--

CREATE SEQUENCE public.analyses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analyses_id_seq OWNER TO dwood;

--
-- Name: analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwood
--

ALTER SEQUENCE public.analyses_id_seq OWNED BY public.analyses.id;


--
-- Name: artists; Type: TABLE; Schema: public; Owner: dwood
--

CREATE TABLE public.artists (
    id integer NOT NULL,
    name character varying NOT NULL,
    spotify_id character varying,
    youtube_channel_id character varying,
    external_ids jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.artists OWNER TO dwood;

--
-- Name: artists_id_seq; Type: SEQUENCE; Schema: public; Owner: dwood
--

CREATE SEQUENCE public.artists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.artists_id_seq OWNER TO dwood;

--
-- Name: artists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwood
--

ALTER SEQUENCE public.artists_id_seq OWNED BY public.artists.id;


--
-- Name: breakout_scores; Type: TABLE; Schema: public; Owner: dwood
--

CREATE TABLE public.breakout_scores (
    id integer NOT NULL,
    artist_id integer NOT NULL,
    score double precision NOT NULL,
    rationale jsonb DEFAULT '{}'::jsonb,
    computed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.breakout_scores OWNER TO dwood;

--
-- Name: breakout_scores_id_seq; Type: SEQUENCE; Schema: public; Owner: dwood
--

CREATE SEQUENCE public.breakout_scores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.breakout_scores_id_seq OWNER TO dwood;

--
-- Name: breakout_scores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwood
--

ALTER SEQUENCE public.breakout_scores_id_seq OWNED BY public.breakout_scores.id;


--
-- Name: catalog_valuations; Type: TABLE; Schema: public; Owner: dwood
--

CREATE TABLE public.catalog_valuations (
    id integer NOT NULL,
    user_id integer NOT NULL,
    tracks jsonb DEFAULT '[]'::jsonb,
    dcf_model jsonb DEFAULT '{}'::jsonb,
    revenue_forecast jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.catalog_valuations OWNER TO dwood;

--
-- Name: catalog_valuations_id_seq; Type: SEQUENCE; Schema: public; Owner: dwood
--

CREATE SEQUENCE public.catalog_valuations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.catalog_valuations_id_seq OWNER TO dwood;

--
-- Name: catalog_valuations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwood
--

ALTER SEQUENCE public.catalog_valuations_id_seq OWNED BY public.catalog_valuations.id;


--
-- Name: collaborations; Type: TABLE; Schema: public; Owner: dwood
--

CREATE TABLE public.collaborations (
    id integer NOT NULL,
    track_id integer,
    artist_ids jsonb DEFAULT '[]'::jsonb,
    impact_projection jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.collaborations OWNER TO dwood;

--
-- Name: collaborations_id_seq; Type: SEQUENCE; Schema: public; Owner: dwood
--

CREATE SEQUENCE public.collaborations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.collaborations_id_seq OWNER TO dwood;

--
-- Name: collaborations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwood
--

ALTER SEQUENCE public.collaborations_id_seq OWNED BY public.collaborations.id;


--
-- Name: embeddings; Type: TABLE; Schema: public; Owner: dwood
--

CREATE TABLE public.embeddings (
    id integer NOT NULL,
    track_id integer NOT NULL,
    vector jsonb NOT NULL,
    model_version character varying DEFAULT 'MiniLM-L6-v2'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.embeddings OWNER TO dwood;

--
-- Name: embeddings_id_seq; Type: SEQUENCE; Schema: public; Owner: dwood
--

CREATE SEQUENCE public.embeddings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.embeddings_id_seq OWNER TO dwood;

--
-- Name: embeddings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwood
--

ALTER SEQUENCE public.embeddings_id_seq OWNED BY public.embeddings.id;


--
-- Name: metrics_daily; Type: TABLE; Schema: public; Owner: dwood
--

CREATE TABLE public.metrics_daily (
    id integer NOT NULL,
    artist_id integer NOT NULL,
    date timestamp without time zone NOT NULL,
    platform character varying NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.metrics_daily OWNER TO dwood;

--
-- Name: metrics_daily_id_seq; Type: SEQUENCE; Schema: public; Owner: dwood
--

CREATE SEQUENCE public.metrics_daily_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.metrics_daily_id_seq OWNER TO dwood;

--
-- Name: metrics_daily_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwood
--

ALTER SEQUENCE public.metrics_daily_id_seq OWNED BY public.metrics_daily.id;


--
-- Name: sources; Type: TABLE; Schema: public; Owner: dwood
--

CREATE TABLE public.sources (
    id integer NOT NULL,
    track_id integer NOT NULL,
    platform character varying NOT NULL,
    external_id character varying NOT NULL,
    url character varying,
    data jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sources OWNER TO dwood;

--
-- Name: sources_id_seq; Type: SEQUENCE; Schema: public; Owner: dwood
--

CREATE SEQUENCE public.sources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sources_id_seq OWNER TO dwood;

--
-- Name: sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwood
--

ALTER SEQUENCE public.sources_id_seq OWNED BY public.sources.id;


--
-- Name: track_assets; Type: TABLE; Schema: public; Owner: dwood
--

CREATE TABLE public.track_assets (
    id integer NOT NULL,
    track_id integer NOT NULL,
    audio_path character varying,
    audio_format character varying,
    lyrics_text text,
    upload_date timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.track_assets OWNER TO dwood;

--
-- Name: track_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: dwood
--

CREATE SEQUENCE public.track_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.track_assets_id_seq OWNER TO dwood;

--
-- Name: track_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwood
--

ALTER SEQUENCE public.track_assets_id_seq OWNED BY public.track_assets.id;


--
-- Name: tracks; Type: TABLE; Schema: public; Owner: dwood
--

CREATE TABLE public.tracks (
    id integer NOT NULL,
    title character varying NOT NULL,
    duration double precision,
    user_id integer NOT NULL,
    artist_id integer,
    spotify_id character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tracks OWNER TO dwood;

--
-- Name: tracks_id_seq; Type: SEQUENCE; Schema: public; Owner: dwood
--

CREATE SEQUENCE public.tracks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tracks_id_seq OWNER TO dwood;

--
-- Name: tracks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwood
--

ALTER SEQUENCE public.tracks_id_seq OWNED BY public.tracks.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: dwood
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying NOT NULL,
    hashed_password character varying NOT NULL,
    full_name character varying,
    is_active boolean DEFAULT true,
    is_superuser boolean DEFAULT false,
    tier character varying DEFAULT 'free'::character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO dwood;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: dwood
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO dwood;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwood
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: analyses id; Type: DEFAULT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.analyses ALTER COLUMN id SET DEFAULT nextval('public.analyses_id_seq'::regclass);


--
-- Name: artists id; Type: DEFAULT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.artists ALTER COLUMN id SET DEFAULT nextval('public.artists_id_seq'::regclass);


--
-- Name: breakout_scores id; Type: DEFAULT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.breakout_scores ALTER COLUMN id SET DEFAULT nextval('public.breakout_scores_id_seq'::regclass);


--
-- Name: catalog_valuations id; Type: DEFAULT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.catalog_valuations ALTER COLUMN id SET DEFAULT nextval('public.catalog_valuations_id_seq'::regclass);


--
-- Name: collaborations id; Type: DEFAULT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.collaborations ALTER COLUMN id SET DEFAULT nextval('public.collaborations_id_seq'::regclass);


--
-- Name: embeddings id; Type: DEFAULT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.embeddings ALTER COLUMN id SET DEFAULT nextval('public.embeddings_id_seq'::regclass);


--
-- Name: metrics_daily id; Type: DEFAULT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.metrics_daily ALTER COLUMN id SET DEFAULT nextval('public.metrics_daily_id_seq'::regclass);


--
-- Name: sources id; Type: DEFAULT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.sources ALTER COLUMN id SET DEFAULT nextval('public.sources_id_seq'::regclass);


--
-- Name: track_assets id; Type: DEFAULT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.track_assets ALTER COLUMN id SET DEFAULT nextval('public.track_assets_id_seq'::regclass);


--
-- Name: tracks id; Type: DEFAULT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.tracks ALTER COLUMN id SET DEFAULT nextval('public.tracks_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: dwood
--

COPY public.alembic_version (version_num) FROM stdin;
0e79531f6eb0
\.


--
-- Data for Name: analyses; Type: TABLE DATA; Schema: public; Owner: dwood
--

COPY public.analyses (id, track_id, sonic_genome, lyrical_genome, hook_data, created_at) FROM stdin;
\.


--
-- Data for Name: artists; Type: TABLE DATA; Schema: public; Owner: dwood
--

COPY public.artists (id, name, spotify_id, youtube_channel_id, external_ids, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: breakout_scores; Type: TABLE DATA; Schema: public; Owner: dwood
--

COPY public.breakout_scores (id, artist_id, score, rationale, computed_at) FROM stdin;
\.


--
-- Data for Name: catalog_valuations; Type: TABLE DATA; Schema: public; Owner: dwood
--

COPY public.catalog_valuations (id, user_id, tracks, dcf_model, revenue_forecast, created_at) FROM stdin;
\.


--
-- Data for Name: collaborations; Type: TABLE DATA; Schema: public; Owner: dwood
--

COPY public.collaborations (id, track_id, artist_ids, impact_projection, created_at) FROM stdin;
\.


--
-- Data for Name: embeddings; Type: TABLE DATA; Schema: public; Owner: dwood
--

COPY public.embeddings (id, track_id, vector, model_version, created_at) FROM stdin;
\.


--
-- Data for Name: metrics_daily; Type: TABLE DATA; Schema: public; Owner: dwood
--

COPY public.metrics_daily (id, artist_id, date, platform, metrics, created_at) FROM stdin;
\.


--
-- Data for Name: sources; Type: TABLE DATA; Schema: public; Owner: dwood
--

COPY public.sources (id, track_id, platform, external_id, url, data, created_at) FROM stdin;
\.


--
-- Data for Name: track_assets; Type: TABLE DATA; Schema: public; Owner: dwood
--

COPY public.track_assets (id, track_id, audio_path, audio_format, lyrics_text, upload_date) FROM stdin;
\.


--
-- Data for Name: tracks; Type: TABLE DATA; Schema: public; Owner: dwood
--

COPY public.tracks (id, title, duration, user_id, artist_id, spotify_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dwood
--

COPY public.users (id, email, hashed_password, full_name, is_active, is_superuser, tier, created_at, updated_at) FROM stdin;
1	dwood@nuper.com	$2b$12$amxXS8XFh5nIgMX10EiWSe6zSDEZgHn6JrIDrf.o6lHzhjGs1SE/m	D Wood	t	f	free	2025-11-01 04:26:58.960236	2025-11-01 04:26:58.960245
\.


--
-- Name: analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwood
--

SELECT pg_catalog.setval('public.analyses_id_seq', 1, false);


--
-- Name: artists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwood
--

SELECT pg_catalog.setval('public.artists_id_seq', 1, true);


--
-- Name: breakout_scores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwood
--

SELECT pg_catalog.setval('public.breakout_scores_id_seq', 1, false);


--
-- Name: catalog_valuations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwood
--

SELECT pg_catalog.setval('public.catalog_valuations_id_seq', 1, false);


--
-- Name: collaborations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwood
--

SELECT pg_catalog.setval('public.collaborations_id_seq', 1, false);


--
-- Name: embeddings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwood
--

SELECT pg_catalog.setval('public.embeddings_id_seq', 1, false);


--
-- Name: metrics_daily_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwood
--

SELECT pg_catalog.setval('public.metrics_daily_id_seq', 1, false);


--
-- Name: sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwood
--

SELECT pg_catalog.setval('public.sources_id_seq', 1, false);


--
-- Name: track_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwood
--

SELECT pg_catalog.setval('public.track_assets_id_seq', 1, false);


--
-- Name: tracks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwood
--

SELECT pg_catalog.setval('public.tracks_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwood
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: analyses analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_pkey PRIMARY KEY (id);


--
-- Name: artists artists_pkey; Type: CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.artists
    ADD CONSTRAINT artists_pkey PRIMARY KEY (id);


--
-- Name: breakout_scores breakout_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.breakout_scores
    ADD CONSTRAINT breakout_scores_pkey PRIMARY KEY (id);


--
-- Name: catalog_valuations catalog_valuations_pkey; Type: CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.catalog_valuations
    ADD CONSTRAINT catalog_valuations_pkey PRIMARY KEY (id);


--
-- Name: collaborations collaborations_pkey; Type: CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.collaborations
    ADD CONSTRAINT collaborations_pkey PRIMARY KEY (id);


--
-- Name: embeddings embeddings_pkey; Type: CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.embeddings
    ADD CONSTRAINT embeddings_pkey PRIMARY KEY (id);


--
-- Name: embeddings embeddings_track_id_key; Type: CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.embeddings
    ADD CONSTRAINT embeddings_track_id_key UNIQUE (track_id);


--
-- Name: metrics_daily metrics_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.metrics_daily
    ADD CONSTRAINT metrics_daily_pkey PRIMARY KEY (id);


--
-- Name: sources sources_pkey; Type: CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.sources
    ADD CONSTRAINT sources_pkey PRIMARY KEY (id);


--
-- Name: track_assets track_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.track_assets
    ADD CONSTRAINT track_assets_pkey PRIMARY KEY (id);


--
-- Name: track_assets track_assets_track_id_key; Type: CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.track_assets
    ADD CONSTRAINT track_assets_track_id_key UNIQUE (track_id);


--
-- Name: tracks tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.tracks
    ADD CONSTRAINT tracks_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_analyses_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_analyses_id ON public.analyses USING btree (id);


--
-- Name: ix_artists_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_artists_id ON public.artists USING btree (id);


--
-- Name: ix_artists_name; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_artists_name ON public.artists USING btree (name);


--
-- Name: ix_artists_spotify_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE UNIQUE INDEX ix_artists_spotify_id ON public.artists USING btree (spotify_id);


--
-- Name: ix_artists_youtube_channel_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE UNIQUE INDEX ix_artists_youtube_channel_id ON public.artists USING btree (youtube_channel_id);


--
-- Name: ix_breakout_scores_computed_at; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_breakout_scores_computed_at ON public.breakout_scores USING btree (computed_at);


--
-- Name: ix_breakout_scores_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_breakout_scores_id ON public.breakout_scores USING btree (id);


--
-- Name: ix_breakout_scores_score; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_breakout_scores_score ON public.breakout_scores USING btree (score);


--
-- Name: ix_catalog_valuations_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_catalog_valuations_id ON public.catalog_valuations USING btree (id);


--
-- Name: ix_collaborations_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_collaborations_id ON public.collaborations USING btree (id);


--
-- Name: ix_embeddings_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_embeddings_id ON public.embeddings USING btree (id);


--
-- Name: ix_metrics_daily_date; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_metrics_daily_date ON public.metrics_daily USING btree (date);


--
-- Name: ix_metrics_daily_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_metrics_daily_id ON public.metrics_daily USING btree (id);


--
-- Name: ix_metrics_daily_platform; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_metrics_daily_platform ON public.metrics_daily USING btree (platform);


--
-- Name: ix_sources_external_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_sources_external_id ON public.sources USING btree (external_id);


--
-- Name: ix_sources_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_sources_id ON public.sources USING btree (id);


--
-- Name: ix_sources_platform; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_sources_platform ON public.sources USING btree (platform);


--
-- Name: ix_track_assets_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_track_assets_id ON public.track_assets USING btree (id);


--
-- Name: ix_tracks_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_tracks_id ON public.tracks USING btree (id);


--
-- Name: ix_tracks_spotify_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE UNIQUE INDEX ix_tracks_spotify_id ON public.tracks USING btree (spotify_id);


--
-- Name: ix_tracks_title; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_tracks_title ON public.tracks USING btree (title);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: dwood
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: dwood
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: analyses analyses_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.tracks(id);


--
-- Name: breakout_scores breakout_scores_artist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.breakout_scores
    ADD CONSTRAINT breakout_scores_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES public.artists(id);


--
-- Name: catalog_valuations catalog_valuations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.catalog_valuations
    ADD CONSTRAINT catalog_valuations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: collaborations collaborations_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.collaborations
    ADD CONSTRAINT collaborations_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.tracks(id);


--
-- Name: embeddings embeddings_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.embeddings
    ADD CONSTRAINT embeddings_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.tracks(id);


--
-- Name: metrics_daily metrics_daily_artist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.metrics_daily
    ADD CONSTRAINT metrics_daily_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES public.artists(id);


--
-- Name: sources sources_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.sources
    ADD CONSTRAINT sources_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.tracks(id);


--
-- Name: track_assets track_assets_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.track_assets
    ADD CONSTRAINT track_assets_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.tracks(id);


--
-- Name: tracks tracks_artist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.tracks
    ADD CONSTRAINT tracks_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES public.artists(id);


--
-- Name: tracks tracks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dwood
--

ALTER TABLE ONLY public.tracks
    ADD CONSTRAINT tracks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict IOQmb81ggiNu7qFEEI84a99TBJcLcfP88PhYjNZ1cchXRHA9jeOgdBO8SBhVUmh

